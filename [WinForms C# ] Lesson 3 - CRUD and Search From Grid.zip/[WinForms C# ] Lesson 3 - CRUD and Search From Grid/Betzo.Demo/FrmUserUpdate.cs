﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Betzo.Demo
{
    public partial class FrmUserUpdate : Form
    {

        public AppUser Model { get; set; } = new AppUser();
        public bool Success { get; set; } = false;

        public FrmUserUpdate()
        {
            InitializeComponent();
        }

        private void FrmUserUpdate_Load(object sender, EventArgs e)
        {
            TxtName.Text = Model.Name;
            TxtEmail.Text = Model.Email;
            TxtUsername.Text = Model.Username;
            TxtPassword.Text = Model.Password;
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            if (TxtName.Text == "")
            {
                MessageBox.Show("Please input name!");
                return;
            }

            if (TxtEmail.Text == "")
            {
                MessageBox.Show("Please email name!");
                return;
            }

            if (TxtUsername.Text == "")
            {
                MessageBox.Show("Please username name!");
                return;
            }

            if (TxtPassword.Text == "")
            {
                MessageBox.Show("Please password name!");
                return;
            }

            var NewModel = new AppUser()
            {
                ID = Model.ID,
                Name = TxtName.Text,
                Email = TxtEmail.Text,
                Username = TxtUsername.Text,
                Password = TxtPassword.Text
            };

            var Result = Saver.UpdateUser(NewModel);

            if (Result == true)
            {
                MessageBox.Show("Successfuly saved!");
                Success = true;
                Close();
            }

        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            var Res = MessageBox.Show("Are you sure you want to delete this record?", "Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (Res == DialogResult.Yes)
            {
                var Result =  Saver.DeleteUser(Model.ID);
                if (Result == true)
                {
                    MessageBox.Show("Successfuly deleted!");
                    Success = true;
                    Close();
                }
            }

        }
    }
}