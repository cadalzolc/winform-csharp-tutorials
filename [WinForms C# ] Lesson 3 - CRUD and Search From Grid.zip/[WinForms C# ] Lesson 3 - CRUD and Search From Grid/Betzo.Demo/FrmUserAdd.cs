﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Betzo.Demo
{
    public partial class FrmUserAdd : Form
    {

        public bool Success { get; set; } = false;

        public FrmUserAdd()
        {
            InitializeComponent();
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {

            if (TxtName.Text == "")
            {
                MessageBox.Show("Please input name!");
                return;
            }

            if (TxtEmail.Text == "")
            {
                MessageBox.Show("Please email name!");
                return;
            }

            if (TxtUsername.Text == "")
            {
                MessageBox.Show("Please username name!");
                return;
            }

            if (TxtPassword.Text == "")
            {
                MessageBox.Show("Please password name!");
                return;
            }

            var Model = new AppUser() 
            {  
                Name = TxtName.Text,
                Email = TxtEmail.Text,
                Username = TxtUsername.Text,
                Password = TxtPassword.Text
            };
            var Result = Saver.SaveNewUser(Model);

            if (Result == true)
            {
                MessageBox.Show("Successfuly saved!");
                Success = true;
                Close();
            }

        }
    }
}