﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Betzo.Demo
{
    public class Saver
    {

        #region " Save New User "

        public static bool SaveNewUser(AppUser Model)
        {
            try
            {
                var Svr = new MyServer();
                using (var Con = new SqlConnection(Svr.ConnectString))
                {
                    Con.Open();
                    using (var Cmd = new SqlCommand("INSERT INTO Tbl_Users (Name, Email, Username, Password) VALUES (@Name, @Email, @Username, @Password)", Con))
                    {
                        Cmd.CommandType = CommandType.Text;
                        Cmd.Parameters.AddWithValue("@Name", Model.Name);
                        Cmd.Parameters.AddWithValue("@Email", Model.Email);
                        Cmd.Parameters.AddWithValue("@Username", Model.Username);
                        Cmd.Parameters.AddWithValue("@Password", Model.Password);
                        Cmd.ExecuteNonQuery();
                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        #endregion

        #region " Update User "

        public static bool UpdateUser(AppUser Model)
        {
            try
            {
                var Svr = new MyServer();
                using (var Con = new SqlConnection(Svr.ConnectString))
                {
                    Con.Open();
                    using (var Cmd = new SqlCommand("UPDATE Tbl_Users SET Name = @Name, Email = @Email, Username = @Username, Password = @Password WHERE PK_ID = @ID", Con))
                    {
                        Cmd.CommandType = CommandType.Text;
                        Cmd.Parameters.AddWithValue("@ID", Model.ID);
                        Cmd.Parameters.AddWithValue("@Name", Model.Name);
                        Cmd.Parameters.AddWithValue("@Email", Model.Email);
                        Cmd.Parameters.AddWithValue("@Username", Model.Username);
                        Cmd.Parameters.AddWithValue("@Password", Model.Password);
                        Cmd.ExecuteNonQuery();
                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }


        #endregion

        #region " Delete User "

        public static bool DeleteUser(int ID)
        {
            try
            {
                var Svr = new MyServer();
                using (var Con = new SqlConnection(Svr.ConnectString))
                {
                    Con.Open();
                    using (var Cmd = new SqlCommand("DELETE FROM Tbl_Users WHERE PK_ID = @ID", Con))
                    {
                        Cmd.CommandType = CommandType.Text;
                        Cmd.Parameters.AddWithValue("@ID", ID);
                        Cmd.ExecuteNonQuery();
                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        #endregion

    }
}
