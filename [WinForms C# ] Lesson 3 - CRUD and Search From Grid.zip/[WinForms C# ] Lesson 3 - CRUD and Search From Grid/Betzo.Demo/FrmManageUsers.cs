﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Betzo.Demo
{
    public partial class FrmManageUsers : Form
    {
        public FrmManageUsers()
        {
            InitializeComponent();
        }

        private void BtnAddUsers_Click(object sender, EventArgs e)
        {
            var Frm = new FrmUserAdd();
            Frm.ShowDialog();
            if (Frm.Success.Equals(true))
            {
                RefreshGrid();
            }
        }

        private void FrmManageUsers_Load(object sender, EventArgs e)
        {
            RefreshGrid();
        }

        void RefreshGrid(string SearchText = "")
        {
            var Svr = new MyServer();
            var DT = Svr.GetData(string.Format("EXEC SP_Search_Users '{0}'", SearchText.Replace("'", "''")));
            GrdUsers.DataSource = null;
            GrdUsers.DataSource = DT;
        }

        private void GrdUsers_RowHeaderMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.RowIndex < 0) return;

            var Model = new AppUser
            {
                ID = Convert.ToInt32(GrdUsers.Rows[e.RowIndex].Cells["PK_ID"].Value),
                Name = GrdUsers.Rows[e.RowIndex].Cells["Name"].Value.ToString(),
                Email = GrdUsers.Rows[e.RowIndex].Cells["Email"].Value.ToString(),
                Username = GrdUsers.Rows[e.RowIndex].Cells["Username"].Value.ToString(),
                Password = GrdUsers.Rows[e.RowIndex].Cells["Password"].Value.ToString()
            };

            var Frm = new FrmUserUpdate
            {
                Model = Model
            };
            Frm.ShowDialog();

            if (Frm.Success.Equals(true))
            {
                RefreshGrid();
            }
        }

        private void BtnSearch_Click(object sender, EventArgs e)
        {
            RefreshGrid(TxtSearch.Text);
        }
    }
}
