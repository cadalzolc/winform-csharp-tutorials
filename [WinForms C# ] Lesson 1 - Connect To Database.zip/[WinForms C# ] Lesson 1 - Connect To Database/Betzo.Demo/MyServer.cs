﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Net.Cache;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Betzo.Demo
{
    public class MyServer
    {

        public string Server { get; set; } = ConfigurationManager.AppSettings["Server"].ToString();
        public string Database { get; set; } = ConfigurationManager.AppSettings["Database"].ToString();
        public string UserID { get; set; } = ConfigurationManager.AppSettings["UID"].ToString();
        public string Password { get; set; } = ConfigurationManager.AppSettings["PWD"].ToString();

        public bool Connected()
        {
            try
            {
                var ConString = string.Format("Server={0}; Database={1}; UID={2}; PWD={3}; Persist Security Info=true;", Server, Database, UserID, Password);

                var Con = new SqlConnection(ConString);
                Con.Open();
                Con.Close();

                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

    }
}
