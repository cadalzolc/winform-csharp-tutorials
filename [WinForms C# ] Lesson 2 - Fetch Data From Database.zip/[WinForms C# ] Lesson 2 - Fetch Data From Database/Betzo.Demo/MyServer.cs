﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net.Cache;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Betzo.Demo
{
    public class MyServer
    {


        #region " Properties "

        public string Server { get; set; } = ConfigurationManager.AppSettings["Server"].ToString();
        public string Database { get; set; } = ConfigurationManager.AppSettings["Database"].ToString();
        public string UserID { get; set; } = ConfigurationManager.AppSettings["UID"].ToString();
        public string Password { get; set; } = ConfigurationManager.AppSettings["PWD"].ToString();
        public string ConnectString => string.Format("Server={0}; Database={1}; UID={2}; PWD={3}; Persist Security Info=true;", Server, Database, UserID, Password);

        #endregion

        #region " Test Connection "

        public bool Connected()
        {
            try
            {
                var ConString = string.Format("Server={0}; Database={1}; UID={2}; PWD={3}; Persist Security Info=true;", Server, Database, UserID, Password);

                var Con = new SqlConnection(ConString);
                Con.Open();
                Con.Close();

                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        #endregion

        #region " Get Data "

        public DataTable GetData(string CommandText)
        {
            try
            {
                using (var Con = new SqlConnection(ConnectString))
                {
                    Con.Open();
                    var DT = new DataTable();
                    var DA = new SqlDataAdapter(CommandText, Con);
                    DA.Fill(DT);
                    return DT;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }
        }

        #endregion

    }
}